﻿const $ = (s) => document.querySelector(s);
const statusBox = $('#status');


function setStatus(msg) {
    statusBox.style.display = 'block';
    statusBox.textContent = msg;
}


async function sendForPrompts(file, brief) {
    setStatus('กำลังประมวลผล…');
    const fd = new FormData();
    if (file) fd.append('image_file', file);
    if (brief) fd.append('edit_brief', brief);
    const r = await fetch('/api/generate-prompts', { method: 'POST', body: fd });
    if (!r.ok) throw new Error(await r.text());
    const data = await r.json();
    setStatus('สร้าง PROMPT เสร็จแล้ว');
    renderPrompts(data.prompts || []);
}


function renderPrompts(prompts) {
    const wrap = $('#results');
    wrap.innerHTML = '';
    prompts.forEach((p, i) => {
        const el = document.createElement('div');
        el.className = 'card';
        el.innerHTML = `
<h3>${p.title_th || 'เวอร์ชัน #' + (i + 1)}</h3>
<p><b>Aspect:</b> ${p.aspect_ratio}</p>
<p><b>Prompt (TH):</b><br>${p.prompt_th}</p>
<p><b>Negative:</b> ${p.negative_prompt_th}</p>
<div class="row">
<button class="btn" data-prompt="${encodeURIComponent(p.prompt_th)}">สร้างรูปจาก Prompt นี้</button>
</div>
`;
        el.querySelector('button').addEventListener('click', async (ev) => {
            const prompt = decodeURIComponent(ev.target.dataset.prompt);
            ev.target.disabled = true; ev.target.textContent = 'กำลังสร้างรูป…';
            try {
                const r = await fetch('/api/generate-image', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ prompt })
                });
                const js = await r.json();
                if (js.image_base64) {
                    const img = new Image();
                    img.src = 'data:image/png;base64,' + js.image_base64;
                    el.appendChild(img);
                } else {
                    alert('ไม่พบภาพที่สร้าง');
                }
            } catch (e) {
                alert('ผิดพลาด: ' + e.message);
            } finally {
                ev.target.disabled = false; ev.target.textContent = 'สร้างรูปจาก Prompt นี้';
            }
        });
        wrap.appendChild(el);
    });
}


// โหมด 1: ปุ่มถาม 2 ข้อ
$('#btnQ').addEventListener('click', () => {
    const f = $('#fileQ').files[0];
    const b = $('#briefQ').value.trim();
    if (!f) { alert('กรุณาแนบรูปก่อน'); return; }
    sendForPrompts(f, b);
});


// โหมด 2: ลากวางรูป
const drop = $('#drop');
['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.style.background = '#f3f4f6'; }));
;['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.style.background = ''; }));


drop.addEventListener('drop', (e) => {
    const f = e.dataTransfer.files[0];
    if (!f) { alert('ไม่พบไฟล์'); return; }
    sendForPrompts(f, '');
});